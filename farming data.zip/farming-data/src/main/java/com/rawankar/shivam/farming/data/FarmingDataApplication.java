package com.rawankar.shivam.farming.data;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FarmingDataApplication {

	public static void main(String[] args) {
		SpringApplication.run(FarmingDataApplication.class, args);
	}

}
